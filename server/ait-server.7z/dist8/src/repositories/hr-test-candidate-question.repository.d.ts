import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { HrTestCandidateQuestion } from '../models';
export declare class HrTestCandidateQuestionRepository extends DefaultCrudRepository<HrTestCandidateQuestion, typeof HrTestCandidateQuestion.prototype.candidateCode> {
    protected datasource: juggler.DataSource;
    constructor(datasource: juggler.DataSource);
}
