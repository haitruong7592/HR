import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { HrTestTemplate } from '../models';
export declare class HrTestTemplateRepository extends DefaultCrudRepository<HrTestTemplate, typeof HrTestTemplate.prototype.code> {
    protected datasource: juggler.DataSource;
    constructor(datasource: juggler.DataSource);
}
