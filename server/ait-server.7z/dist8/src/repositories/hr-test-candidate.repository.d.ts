import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { HrTestCandidate } from '../models';
export declare class HrTestCandidateRepository extends DefaultCrudRepository<HrTestCandidate, typeof HrTestCandidate.prototype.candidateCode> {
    protected datasource: juggler.DataSource;
    constructor(datasource: juggler.DataSource);
}
