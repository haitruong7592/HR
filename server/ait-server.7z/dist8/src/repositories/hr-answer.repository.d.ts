import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { HrAnswer } from '../models';
export declare class HrAnswerRepository extends DefaultCrudRepository<HrAnswer, typeof HrAnswer.prototype.id> {
    protected datasource: juggler.DataSource;
    constructor(datasource: juggler.DataSource);
}
