import { AITApplication } from './application';
import { ApplicationConfig } from '@loopback/core';
export { AITApplication };
export declare function main(options?: ApplicationConfig): Promise<AITApplication>;
