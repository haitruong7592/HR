import { Filter, Where } from '@loopback/repository';
import { HrAnswer } from '../models';
import { HrAnswerRepository } from '../repositories';
export declare class HrAnswerController {
    hrAnswerRepository: HrAnswerRepository;
    constructor(hrAnswerRepository: HrAnswerRepository);
    create(obj: HrAnswer): Promise<HrAnswer>;
    count(where?: Where): Promise<number>;
    find(filter?: Filter): Promise<HrAnswer[]>;
    updateAll(obj: HrAnswer, where?: Where): Promise<number>;
    findById(id: number): Promise<HrAnswer>;
    updateById(id: number, obj: HrAnswer): Promise<boolean>;
    deleteById(id: number): Promise<boolean>;
}
