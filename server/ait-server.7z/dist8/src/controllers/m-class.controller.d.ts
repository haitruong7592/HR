import { Filter, Where } from '@loopback/repository';
import { MClass } from '../models';
import { MClassRepository } from '../repositories';
export declare class MClassController {
    mClassRepository: MClassRepository;
    constructor(mClassRepository: MClassRepository);
    create(obj: MClass): Promise<MClass>;
    count(where?: Where): Promise<number>;
    find(filter?: Filter): Promise<MClass[]>;
    updateAll(obj: MClass, where?: Where): Promise<number>;
    deleteAll(where?: Where): Promise<number>;
    findById(id: string): Promise<MClass>;
    updateById(id: string, obj: MClass): Promise<boolean>;
    deleteById(id: string): Promise<boolean>;
}
