import { Filter, Where } from '@loopback/repository';
import { HrTestTemplateDetail } from '../models';
import { HrTestTemplateDetailRepository } from '../repositories';
export declare class HrTestTemplateDetailController {
    hrTestTemplateDetailRepository: HrTestTemplateDetailRepository;
    constructor(hrTestTemplateDetailRepository: HrTestTemplateDetailRepository);
    create(obj: HrTestTemplateDetail): Promise<HrTestTemplateDetail>;
    count(where?: Where): Promise<number>;
    find(filter?: Filter): Promise<HrTestTemplateDetail[]>;
    updateAll(obj: HrTestTemplateDetail, where?: Where): Promise<number>;
    deleteAll(where?: Where): Promise<number>;
    findById(id: string): Promise<HrTestTemplateDetail>;
    updateById(id: string, obj: HrTestTemplateDetail): Promise<boolean>;
    deleteById(id: string): Promise<boolean>;
}
