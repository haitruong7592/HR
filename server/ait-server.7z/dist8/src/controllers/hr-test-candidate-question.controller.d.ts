import { Filter, Where } from '@loopback/repository';
import { HrTestCandidateQuestion } from '../models';
import { HrTestCandidateQuestionRepository } from '../repositories';
export declare class HrTestCandidateQuestionController {
    hrTestCandidateQuestionRepository: HrTestCandidateQuestionRepository;
    constructor(hrTestCandidateQuestionRepository: HrTestCandidateQuestionRepository);
    create(obj: HrTestCandidateQuestion): Promise<HrTestCandidateQuestion>;
    count(where?: Where): Promise<number>;
    find(filter?: Filter): Promise<HrTestCandidateQuestion[]>;
    updateAll(obj: HrTestCandidateQuestion, where?: Where): Promise<number>;
    findById(id: string): Promise<HrTestCandidateQuestion>;
    updateById(id: string, obj: HrTestCandidateQuestion): Promise<boolean>;
    deleteById(id: string): Promise<boolean>;
}
