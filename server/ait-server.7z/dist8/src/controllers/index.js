"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./ping.controller"));
__export(require("./hr-candidate.controller"));
__export(require("./m-class.controller"));
__export(require("./hr-test-template.controller"));
__export(require("./hr-test-template-detail.controller"));
__export(require("./hr-answer.controller"));
__export(require("./hr-question.controller"));
__export(require("./hr-test-candidate.controller"));
__export(require("./hr-test-candidate-answer.controller"));
__export(require("./hr-test-candidate-question.controller"));
//# sourceMappingURL=index.js.map