import { juggler, AnyObject } from '@loopback/repository';
export declare class AitDataSource extends juggler.DataSource {
    static dataSourceName: string;
    constructor(dsConfig?: AnyObject);
}
