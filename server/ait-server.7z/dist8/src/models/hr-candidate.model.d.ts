import { Entity } from '@loopback/repository';
export declare class HrCandidate extends Entity {
    code: string;
    name?: string;
    email?: string;
    phone?: string;
    position?: string;
    testTemplate?: string;
    testResult?: string;
    username?: string;
    password?: string;
    constructor(data?: Partial<HrCandidate>);
}
