import { Entity } from '@loopback/repository';
export declare class HrTestTemplate extends Entity {
    code: string;
    name: string;
    time?: number;
    activeFlag?: boolean;
    constructor(data?: Partial<HrTestTemplate>);
}
