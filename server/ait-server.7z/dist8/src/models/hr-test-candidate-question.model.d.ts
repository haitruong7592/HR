import { Entity } from '@loopback/repository';
export declare class HrTestCandidateQuestion extends Entity {
    candidateCode: string;
    category: string;
    no: number;
    questionId: number;
    content?: string;
    image?: string;
    constructor(data?: Partial<HrTestCandidateQuestion>);
}
