import { Entity } from '@loopback/repository';
export declare class HrQuestion extends Entity {
    id: number;
    category: string;
    level: string;
    content: string;
    image?: string;
    activeflag?: boolean;
    constructor(data?: Partial<HrQuestion>);
}
