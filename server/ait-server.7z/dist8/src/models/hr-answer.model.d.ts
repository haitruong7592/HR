import { Entity } from '@loopback/repository';
export declare class HrAnswer extends Entity {
    id: number;
    content?: string;
    image?: string;
    questionid: number;
    correct?: boolean;
    constructor(data?: Partial<HrAnswer>);
}
