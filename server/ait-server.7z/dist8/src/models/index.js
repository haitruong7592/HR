"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./hr-candidate.model"));
__export(require("./m-class.model"));
__export(require("./hr-test-template.model"));
__export(require("./hr-test-template-detail.model"));
__export(require("./hr-answer.model"));
__export(require("./hr-question.model"));
__export(require("./hr-test-candidate.model"));
__export(require("./hr-test-candidate-answer.model"));
__export(require("./hr-test-candidate-question.model"));
//# sourceMappingURL=index.js.map