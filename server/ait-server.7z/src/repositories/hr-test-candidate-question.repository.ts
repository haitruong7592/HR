import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { HrTestCandidateQuestion } from '../models';
import { inject } from '@loopback/core';

export class HrTestCandidateQuestionRepository extends DefaultCrudRepository<
  HrTestCandidateQuestion,
  typeof HrTestCandidateQuestion.prototype.candidateCode
  > {
  constructor(
    @inject('datasources.ait') protected datasource: juggler.DataSource,
  ) {
    super(HrTestCandidateQuestion, datasource);
  }
}
