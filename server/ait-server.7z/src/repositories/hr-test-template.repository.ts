import {DefaultCrudRepository, juggler} from '@loopback/repository';
import {inject} from '@loopback/core';
import {HrTestTemplate} from '../models';

export class HrTestTemplateRepository extends DefaultCrudRepository<
  HrTestTemplate,
  typeof HrTestTemplate.prototype.code
> {
  constructor(
    @inject('datasources.ait') protected datasource: juggler.DataSource,
  ) {
    super(HrTestTemplate, datasource);
  }
}
