import {DefaultCrudRepository, juggler} from '@loopback/repository';
import {HrCandidate} from '../models';
import {inject} from '@loopback/core';

export class HrCandidateRepository extends DefaultCrudRepository<
  HrCandidate,
  typeof HrCandidate.prototype.code
> {
  constructor(
    @inject('datasources.ait') protected datasource: juggler.DataSource,
  ) {
    super(HrCandidate, datasource);
  }
}