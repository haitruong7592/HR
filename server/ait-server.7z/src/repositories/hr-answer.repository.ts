import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { HrAnswer } from '../models';
import { inject } from '@loopback/core';

export class HrAnswerRepository extends DefaultCrudRepository<
  HrAnswer,
  typeof HrAnswer.prototype.id
  > {
  constructor(
    @inject('datasources.ait') protected datasource: juggler.DataSource,
  ) {
    super(HrAnswer, datasource);
  }
}
