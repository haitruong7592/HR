import {inject} from '@loopback/core';
import {juggler, DataSource, AnyObject} from '@loopback/repository';
const config = require('./ait.datasource.json');

export class AitDataSource extends juggler.DataSource {
  static dataSourceName = 'ait';

  constructor(
    @inject('datasources.config.ait', {optional: true})
    dsConfig: AnyObject = config
  ) {
    super(dsConfig);
  }
}
