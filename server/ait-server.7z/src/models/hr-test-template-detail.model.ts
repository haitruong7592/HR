import { Entity, model, property } from '@loopback/repository';

@model({ name: 'hr_test_template_detail' })
export class HrTestTemplateDetail extends Entity {

  @property({
    type: 'string',
    id: true,
    required: true,

  })
  testTemplateId: string;

  @property({
    type: 'string',
    required: true,

  })
  category: string;

  @property({
    type: 'string',
    required: true,

  })
  level: string;

  @property({
    type: 'number',

  })
  quantity?: number;

  constructor(data?: Partial<HrTestTemplateDetail>) {
    super(data);
  }
}
