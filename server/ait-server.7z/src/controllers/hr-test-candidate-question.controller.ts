import {Filter, Where, repository} from '@loopback/repository';
import {
  post,
  param,
  get,
  patch,
  del,
  requestBody
} from '@loopback/rest';
import {HrTestCandidateQuestion} from '../models';
import {HrTestCandidateQuestionRepository} from '../repositories';

export class HrTestCandidateQuestionController {
  constructor(
    @repository(HrTestCandidateQuestionRepository)
    public hrTestCandidateQuestionRepository : HrTestCandidateQuestionRepository,
  ) {}

  @post('/hr-test-candidate-questions')
  async create(@requestBody() obj: HrTestCandidateQuestion)
    : Promise<HrTestCandidateQuestion> {
    return await this.hrTestCandidateQuestionRepository.create(obj);
  }

  @get('/hr-test-candidate-questions/count')
  async count(@param.query.string('where') where?: Where): Promise<number> {
    return await this.hrTestCandidateQuestionRepository.count(where);
  }

  @get('/hr-test-candidate-questions')
  async find(@param.query.string('filter') filter?: Filter)
    : Promise<HrTestCandidateQuestion[]> {
    return await this.hrTestCandidateQuestionRepository.find(filter);
  }

  @patch('/hr-test-candidate-questions')
  async updateAll(
    @requestBody() obj: HrTestCandidateQuestion,
    @param.query.string('where') where?: Where
  ): Promise<number> {
    return await this.hrTestCandidateQuestionRepository.updateAll(obj, where);
  }

  @get('/hr-test-candidate-questions/{id}')
  async findById(@param.path.string('id') id: string): Promise<HrTestCandidateQuestion> {
    return await this.hrTestCandidateQuestionRepository.findById(id);
  }

  @patch('/hr-test-candidate-questions/{id}')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody() obj: HrTestCandidateQuestion
  ): Promise<boolean> {
    return await this.hrTestCandidateQuestionRepository.updateById(id, obj);
  }

  @del('/hr-test-candidate-questions/{id}')
  async deleteById(@param.path.string('id') id: string): Promise<boolean> {
    return await this.hrTestCandidateQuestionRepository.deleteById(id);
  }
}
