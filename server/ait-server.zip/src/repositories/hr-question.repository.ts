import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { HrQuestion } from '../models';
import { inject } from '@loopback/core';

export class HrQuestionRepository extends DefaultCrudRepository<
  HrQuestion,
  typeof HrQuestion.prototype.id
  > {
  constructor(
    @inject('datasources.ait') protected datasource: juggler.DataSource,
  ) {
    super(HrQuestion, datasource);
  }
}
