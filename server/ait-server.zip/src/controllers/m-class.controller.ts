import {Filter, Where, repository} from '@loopback/repository';
import {
  post,
  param,
  get,
  patch,
  del,
  requestBody
} from '@loopback/rest';
import {MClass} from '../models';
import {MClassRepository} from '../repositories';

export class MClassController {
  constructor(
    @repository(MClassRepository)
    public mClassRepository : MClassRepository,
  ) {}

  @post('/m-classes')
  async create(@requestBody() obj: MClass)
    : Promise<MClass> {
    return await this.mClassRepository.create(obj);
  }

  @get('/m-classes/count')
  async count(@param.query.string('where') where?: Where): Promise<number> {
    return await this.mClassRepository.count(where);
  }

  @get('/m-classes')
  async find(@param.query.string('filter') filter?: Filter)
    : Promise<MClass[]> {
    return await this.mClassRepository.find(filter);
  }

  @patch('/m-classes')
  async updateAll(
    @requestBody() obj: MClass,
    @param.query.string('where') where?: Where,
  ): Promise<number> {
    return await this.mClassRepository.updateAll(obj, where);
  }

  @del('/m-classes')
  async deleteAll(@param.query.string('where') where?: Where): Promise<number> {
    return await this.mClassRepository.deleteAll(where);
  }

  @get('/m-classes/{id}')
  async findById(@param.path.string('id') id: string): Promise<MClass> {
    return await this.mClassRepository.findById(id);
  }

  @patch('/m-classes/{id}')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody() obj: MClass
  ): Promise<boolean> {
    return await this.mClassRepository.updateById(id, obj);
  }

  @del('/m-classes/{id}')
  async deleteById(@param.path.string('id') id: string): Promise<boolean> {
    return await this.mClassRepository.deleteById(id);
  }
}
