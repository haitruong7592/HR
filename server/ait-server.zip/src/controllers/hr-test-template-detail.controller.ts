import {Filter, Where, repository} from '@loopback/repository';
import {
  post,
  param,
  get,
  patch,
  del,
  requestBody
} from '@loopback/rest';
import {HrTestTemplateDetail} from '../models';
import {HrTestTemplateDetailRepository} from '../repositories';

export class HrTestTemplateDetailController {
  constructor(
    @repository(HrTestTemplateDetailRepository)
    public hrTestTemplateDetailRepository : HrTestTemplateDetailRepository,
  ) {}

  @post('/hr-test-template-details')
  async create(@requestBody() obj: HrTestTemplateDetail)
    : Promise<HrTestTemplateDetail> {
    return await this.hrTestTemplateDetailRepository.create(obj);
  }

  @get('/hr-test-template-details/count')
  async count(@param.query.string('where') where?: Where): Promise<number> {
    return await this.hrTestTemplateDetailRepository.count(where);
  }

  @get('/hr-test-template-details')
  async find(@param.query.string('filter') filter?: Filter)
    : Promise<HrTestTemplateDetail[]> {
    return await this.hrTestTemplateDetailRepository.find(filter);
  }

  @patch('/hr-test-template-details')
  async updateAll(
    @requestBody() obj: HrTestTemplateDetail,
    @param.query.string('where') where?: Where,
  ): Promise<number> {
    return await this.hrTestTemplateDetailRepository.updateAll(obj, where);
  }

  @del('/hr-test-template-details')
  async deleteAll(@param.query.string('where') where?: Where): Promise<number> {
    return await this.hrTestTemplateDetailRepository.deleteAll(where);
  }

  @get('/hr-test-template-details/{id}')
  async findById(@param.path.string('id') id: string): Promise<HrTestTemplateDetail> {
    return await this.hrTestTemplateDetailRepository.findById(id);
  }

  @patch('/hr-test-template-details/{id}')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody() obj: HrTestTemplateDetail
  ): Promise<boolean> {
    return await this.hrTestTemplateDetailRepository.updateById(id, obj);
  }

  @del('/hr-test-template-details/{id}')
  async deleteById(@param.path.string('id') id: string): Promise<boolean> {
    return await this.hrTestTemplateDetailRepository.deleteById(id);
  }
}
