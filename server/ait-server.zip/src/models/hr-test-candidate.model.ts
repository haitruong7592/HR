import { Entity, model, property } from '@loopback/repository';

@model({ name: 'hr_test_candidate' })
export class HrTestCandidate extends Entity {

  @property({
    type: 'string',
    id: true,
    required: true,
  })
  candidateCode: string;

  @property({
    type: 'string',
    required: true,
  })
  templateCode: string;

  @property({
    type: 'string',
  })
  startTime?: string;

  @property({
    type: 'string',
  })
  endTime?: string;

  @property({
    type: 'string',
  })
  resultTest?: string;

  constructor(data?: Partial<HrTestCandidate>) {
    super(data);
  }
}
