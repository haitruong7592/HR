import { Entity, model, property } from '@loopback/repository';

@model({ name: 'hr_test_candidate_answer' })
export class HrTestCandidateAnswer extends Entity {
  @property({
    type: 'string',
    id: true,
    required: true,
  })
  candidateCode: string;

  @property({
    type: 'number',
    required: true,
  })
  questionId: number;

  @property({
    type: 'number',
    required: true,
  })
  answerId: number;

  @property({
    type: 'string',
  })
  content?: string;

  @property({
    type: 'string',
  })
  image?: string;

  @property({
    type: 'boolean',
    required: true,
  })
  systemAnswer: boolean;

  @property({
    type: 'boolean',
  })
  candidateAnswer?: boolean;

  constructor(data?: Partial<HrTestCandidateAnswer>) {
    super(data);
  }
}
