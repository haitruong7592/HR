import { Entity, model, property } from '@loopback/repository';

@model({ name: 'hr_question' })
export class HrQuestion extends Entity {
  @property({
    type: 'number',
    id: true,
    required: true,
  })
  id: number;

  @property({
    type: 'string',
    required: true,
  })
  category: string;

  @property({
    type: 'string',
    required: true,
  })
  level: string;

  @property({
    type: 'string',
    required: true,
  })
  content: string;

  @property({
    type: 'string',
  })
  image?: string;

  @property({
    type: 'boolean',
  })
  activeflag?: boolean;

  constructor(data?: Partial<HrQuestion>) {
    super(data);
  }
}
