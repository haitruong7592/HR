import { Entity } from '@loopback/repository';
export declare class HrTestTemplateDetail extends Entity {
    testTemplateId: string;
    category: string;
    level: string;
    quantity?: number;
    constructor(data?: Partial<HrTestTemplateDetail>);
}
