import { Entity } from '@loopback/repository';
export declare class MClass extends Entity {
    precode: string;
    code: string;
    name: string;
    constructor(data?: Partial<MClass>);
}
