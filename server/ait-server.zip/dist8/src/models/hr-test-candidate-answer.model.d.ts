import { Entity } from '@loopback/repository';
export declare class HrTestCandidateAnswer extends Entity {
    candidateCode: string;
    questionId: number;
    answerId: number;
    content?: string;
    image?: string;
    systemAnswer: boolean;
    candidateAnswer?: boolean;
    constructor(data?: Partial<HrTestCandidateAnswer>);
}
