import { Entity } from '@loopback/repository';
export declare class HrTestCandidate extends Entity {
    candidateCode: string;
    templateCode: string;
    startTime?: string;
    endTime?: string;
    resultTest?: string;
    constructor(data?: Partial<HrTestCandidate>);
}
