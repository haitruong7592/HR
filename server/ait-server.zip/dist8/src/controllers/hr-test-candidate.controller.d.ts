import { Filter, Where } from '@loopback/repository';
import { HrTestCandidate } from '../models';
import { HrTestCandidateRepository } from '../repositories';
export declare class HrTestCandidateController {
    hrTestCandidateRepository: HrTestCandidateRepository;
    constructor(hrTestCandidateRepository: HrTestCandidateRepository);
    create(obj: HrTestCandidate): Promise<HrTestCandidate>;
    count(where?: Where): Promise<number>;
    find(filter?: Filter): Promise<HrTestCandidate[]>;
    updateAll(obj: HrTestCandidate, where?: Where): Promise<number>;
    findById(id: string): Promise<HrTestCandidate>;
    updateById(id: string, obj: HrTestCandidate): Promise<boolean>;
    deleteById(id: string): Promise<boolean>;
}
