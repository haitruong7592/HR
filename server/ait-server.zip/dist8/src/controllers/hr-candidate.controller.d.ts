import { Filter, Where } from '@loopback/repository';
import { HrCandidate } from '../models';
import { HrCandidateRepository } from '../repositories';
export declare class HrCandidateController {
    hrCandidateRepository: HrCandidateRepository;
    constructor(hrCandidateRepository: HrCandidateRepository);
    create(obj: HrCandidate): Promise<HrCandidate>;
    count(where?: Where): Promise<number>;
    find(filter?: Filter): Promise<HrCandidate[]>;
    updateAll(obj: HrCandidate, where?: Where): Promise<number>;
    deleteAll(where?: Where): Promise<number>;
    findById(id: string): Promise<HrCandidate>;
    updateById(id: string, obj: HrCandidate): Promise<boolean>;
    deleteById(id: string): Promise<boolean>;
}
