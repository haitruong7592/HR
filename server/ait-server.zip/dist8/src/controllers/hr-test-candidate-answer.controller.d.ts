import { Filter, Where } from '@loopback/repository';
import { HrTestCandidateAnswer } from '../models';
import { HrTestCandidateAnswerRepository } from '../repositories';
export declare class HrTestCandidateAnswerController {
    hrTestCandidateAnswerRepository: HrTestCandidateAnswerRepository;
    constructor(hrTestCandidateAnswerRepository: HrTestCandidateAnswerRepository);
    create(obj: HrTestCandidateAnswer): Promise<HrTestCandidateAnswer>;
    count(where?: Where): Promise<number>;
    find(filter?: Filter): Promise<HrTestCandidateAnswer[]>;
    updateAll(obj: HrTestCandidateAnswer, where?: Where): Promise<number>;
    findById(id: string): Promise<HrTestCandidateAnswer>;
    updateById(id: string, obj: HrTestCandidateAnswer): Promise<boolean>;
    deleteById(id: string): Promise<boolean>;
}
