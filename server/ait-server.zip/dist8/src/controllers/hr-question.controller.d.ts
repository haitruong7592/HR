import { Filter, Where } from '@loopback/repository';
import { HrQuestion } from '../models';
import { HrQuestionRepository } from '../repositories';
export declare class HrQuestionController {
    hrQuestionRepository: HrQuestionRepository;
    constructor(hrQuestionRepository: HrQuestionRepository);
    create(obj: HrQuestion): Promise<HrQuestion>;
    count(where?: Where): Promise<number>;
    find(filter?: Filter): Promise<HrQuestion[]>;
    updateAll(obj: HrQuestion, where?: Where): Promise<number>;
    findById(id: number): Promise<HrQuestion>;
    updateById(id: number, obj: HrQuestion): Promise<boolean>;
    deleteById(id: number): Promise<boolean>;
}
