import { Filter, Where } from '@loopback/repository';
import { HrTestTemplate } from '../models';
import { HrTestTemplateRepository } from '../repositories';
export declare class HrTestTemplateController {
    hrTestTemplateRepository: HrTestTemplateRepository;
    constructor(hrTestTemplateRepository: HrTestTemplateRepository);
    create(obj: HrTestTemplate): Promise<HrTestTemplate>;
    count(where?: Where): Promise<number>;
    find(filter?: Filter): Promise<HrTestTemplate[]>;
    updateAll(obj: HrTestTemplate, where?: Where): Promise<number>;
    deleteAll(where?: Where): Promise<number>;
    findById(id: string): Promise<HrTestTemplate>;
    updateById(id: string, obj: HrTestTemplate): Promise<boolean>;
    deleteById(id: string): Promise<boolean>;
}
