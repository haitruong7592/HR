import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { HrTestTemplateDetail } from '../models/hr-test-template-detail.model';
export declare class HrTestTemplateDetailRepository extends DefaultCrudRepository<HrTestTemplateDetail, typeof HrTestTemplateDetail.prototype.testTemplateId> {
    protected datasource: juggler.DataSource;
    constructor(datasource: juggler.DataSource);
}
