import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { HrTestCandidateAnswer } from '../models';
export declare class HrTestCandidateAnswerRepository extends DefaultCrudRepository<HrTestCandidateAnswer, typeof HrTestCandidateAnswer.prototype.candidateCode> {
    protected datasource: juggler.DataSource;
    constructor(datasource: juggler.DataSource);
}
