import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { HrCandidate } from '../models';
export declare class HrCandidateRepository extends DefaultCrudRepository<HrCandidate, typeof HrCandidate.prototype.code> {
    protected datasource: juggler.DataSource;
    constructor(datasource: juggler.DataSource);
}
