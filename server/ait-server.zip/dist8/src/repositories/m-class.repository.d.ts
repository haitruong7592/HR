import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { MClass } from '../models';
export declare class MClassRepository extends DefaultCrudRepository<MClass, typeof MClass.prototype.precode> {
    protected datasource: juggler.DataSource;
    constructor(datasource: juggler.DataSource);
}
