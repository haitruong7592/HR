"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
Object.defineProperty(exports, "__esModule", { value: true });
__export(require("./hr-candidate.repository"));
__export(require("./m-class.repository"));
__export(require("./hr-test-template.repository"));
__export(require("./hr-test-template-detail.repository"));
__export(require("./hr-answer.repository"));
__export(require("./hr-question.repository"));
__export(require("./hr-test-candidate.repository"));
__export(require("./hr-test-candidate-answer.repository"));
__export(require("./hr-test-candidate-question.repository"));
//# sourceMappingURL=index.js.map