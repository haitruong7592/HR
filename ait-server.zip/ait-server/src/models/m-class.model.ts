import {Entity, model, property} from '@loopback/repository';

@model({name: 'm_class'})
export class MClass extends Entity {
  
  @property({
    type: 'string',
    id: true,
    required: true,
    
  })
  precode: string;
  
  @property({
    type: 'string',
    id: true,
    required: true,
    
  })
  code: string;
  
  @property({
    type: 'string',
    required: true,
    
  })
  name: string;
  
  constructor(data?: Partial<MClass>) {
    super(data);
  }
}
