import {Filter, Where, repository} from '@loopback/repository';
import {
  post,
  param,
  get,
  patch,
  del,
  requestBody
} from '@loopback/rest';
import {HrQuestion} from '../models';
import {HrQuestionRepository} from '../repositories';

export class HrQuestionController {
  constructor(
    @repository(HrQuestionRepository)
    public hrQuestionRepository : HrQuestionRepository,
  ) {}

  @post('/hr-questions')
  async create(@requestBody() obj: HrQuestion)
    : Promise<HrQuestion> {
    return await this.hrQuestionRepository.create(obj);
  }

  @get('/hr-questions/count')
  async count(@param.query.string('where') where?: Where): Promise<number> {
    return await this.hrQuestionRepository.count(where);
  }

  @get('/hr-questions')
  async find(@param.query.string('filter') filter?: Filter)
    : Promise<HrQuestion[]> {
    return await this.hrQuestionRepository.find(filter);
  }

  @patch('/hr-questions')
  async updateAll(
    @requestBody() obj: HrQuestion,
    @param.query.string('where') where?: Where
  ): Promise<number> {
    return await this.hrQuestionRepository.updateAll(obj, where);
  }

  @get('/hr-questions/{id}')
  async findById(@param.path.number('id') id: number): Promise<HrQuestion> {
    return await this.hrQuestionRepository.findById(id);
  }

  @patch('/hr-questions/{id}')
  async updateById(
    @param.path.number('id') id: number,
    @requestBody() obj: HrQuestion
  ): Promise<boolean> {
    return await this.hrQuestionRepository.updateById(id, obj);
  }

  @del('/hr-questions/{id}')
  async deleteById(@param.path.number('id') id: number): Promise<boolean> {
    return await this.hrQuestionRepository.deleteById(id);
  }
}
