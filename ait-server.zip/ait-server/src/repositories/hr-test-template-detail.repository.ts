import {DefaultCrudRepository, juggler} from '@loopback/repository';
import {inject} from '@loopback/core';
import {HrTestTemplate} from '../models';
import { HrTestTemplateDetail } from '../models/hr-test-template-detail.model';

export class HrTestTemplateDetailRepository extends DefaultCrudRepository<
  HrTestTemplateDetail,
  typeof HrTestTemplateDetail.prototype.testTemplateId
> {
  constructor(
    @inject('datasources.ait') protected datasource: juggler.DataSource,
  ) {
    super(HrTestTemplateDetail, datasource);
  }
}
