import { Deserializable } from '@app/models/deserializable.model';

export class HrCandidate implements Deserializable {
  code: string;
  name: string;
  email: string;
  phone: string;
  position: string;
  positionName: string;
  testTemplate: string;
  testTemplateName: string;
  testResult: string;
  username: string;
  password: string;

  constructor() {}

  deserialize(input: any) {
    Object.assign(<any>this, input);
    return this;
  }
}
