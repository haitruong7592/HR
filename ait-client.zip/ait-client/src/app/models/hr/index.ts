export {HrCandidate} from '@app/models/hr/hr-candidate.model';
