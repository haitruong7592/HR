import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-base-search',
  templateUrl: './base-search.component.html',
  styleUrls: ['./base-search.component.scss']
})
export class BaseSearchComponent implements OnInit {
  pagingList = [5, 10, 20, 50, 100];
  panelConditionState = true;
  panelResultState = true;

  constructor() {}

  ngOnInit() {}
}
