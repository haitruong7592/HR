import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Hr005Component } from '@app/pages/hr/hr005/hr005.component';
import { Hr005InputComponent } from '@app/pages/hr/hr005/hr005-input/hr005-input.component';

const routes: Routes = [
  { path: 'hr005', component: Hr005Component },
  { path: 'hr005-input', component: Hr005InputComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class HrRoutingModule {}
