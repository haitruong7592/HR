import { Component, OnInit, ViewChild } from '@angular/core';
import { HrCandidate } from '@app/models/hr/hr-candidate.model';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { HttpService } from '@app/core/http/http.service';
import { MClass } from '@app/models/m-class.model';
import { MatPaginator, MatTableDataSource, MatDialog, MatSort } from '@angular/material';
import { BaseSearchComponent } from '@app/shared';
import { Subscriber, Observable, forkJoin, merge } from 'rxjs';
import { mergeAll } from '../../../../../node_modules/rxjs/operators';
import { Hr005InputComponent } from '@app/pages/hr/hr005/hr005-input/hr005-input.component';

@Component({
  selector: 'app-hr005',
  templateUrl: './hr005.component.html',
  styleUrls: ['./hr005.component.scss']
})
export class Hr005Component extends BaseSearchComponent implements OnInit {
  // Search condition
  model: HrCandidate;
  positions: any;
  positionSelected = '';
  templates: any;
  templateSelected = '';
  // Data table
  displayedColumns: string[] = [
    'code',
    'name',
    'email',
    'phone',
    'positionName',
    'testTemplateName',
    'username',
    'password'
  ];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource: any = new MatTableDataSource<HrCandidate>([]);

  constructor(private httpService: HttpService, public dialog: MatDialog) {
    super();
  }

  /**
   * Initialize data
   *
   * @memberof Hr005Component
   */
  ngOnInit() {
    this.model = new HrCandidate();
    // get position data
    const sub1 = this.httpService.get(API_URL.M_CLASS_GET).subscribe((res: any) => {
      this.positions = res.filter((e: any) => e.precode === CLASS.POSITION);
      this.positions.unshift(new MClass());
    });
    // get test template data
    const sub2 = this.httpService.get(API_URL.HR_TEST_TEMPLATE_GET).subscribe((res: any) => {
      this.templates = res;
      this.templates.unshift(new MClass());
    });
    // merge data before set name for position and test template
    merge([sub1, sub2]).subscribe(() => {
      this.httpService.get(API_URL.HR_CANDIDATE_GET).subscribe((res: any) => {
        res.forEach((element: any) => {
          element.positionName = this.getPositionName(element.position);
          element.testTemplateName = this.getTestTemplateName(element.testTemplate);
        });
        this.dataSource = new MatTableDataSource<HrCandidate>(res);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
    });
  }

  /**
   * Get name for position
   *
   * @param {string} code
   * @returns
   * @memberof Hr005Component
   */
  getPositionName(code: string) {
    const ret = this.positions.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }

  /**
   * Get name for test template
   *
   * @param {string} code
   * @returns
   * @memberof Hr005Component
   */
  getTestTemplateName(code: string) {
    const ret = this.templates.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }

  openDialog() {
    const dialogRef = this.dialog.open(Hr005InputComponent);
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }
}
