import { Component, OnInit } from '@angular/core';
import { HrCandidate } from '@app/models/hr';

@Component({
  selector: 'app-hr005-input',
  templateUrl: './hr005-input.component.html',
  styleUrls: ['./hr005-input.component.scss']
})
export class Hr005InputComponent implements OnInit {

  model: HrCandidate;
  positions: any;
  positionSelected = '';
  templates: any;
  templateSelected = '';
  constructor() { }

  ngOnInit() {
    this.model = new HrCandidate();
  }

}
