import { Injectable } from '@angular/core';
import { HttpService } from '@app/core/http/http.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HrService {
  constructor(private httpService: HttpService) {}

  getHrCandidates(): Observable<any> {
    return this.httpService.get('/hr-candidates');
  }
}
