import { Injectable } from '@angular/core';
import { HttpService } from '@app/core/http/http.service';
import { Observable } from 'rxjs';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HrCandidate, HrCandidateDto } from '@app/models/hr/hr-candidate.model';
import { HrQuestion, HrQuestionDto } from '@app/models/hr/hr-question.model';
import { HrAnswer } from '@app/models/hr/hr-answer.model';
import {HrTestTemplate} from '@app/models/hr/hr-test-template.model';
import {HrTestTemplateDetail} from '@app/models/hr/hr-test-template-detail.model';
import { MClass } from '@app/models/m-class.model';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})


export class HrService {
  constructor(private httpService: HttpService) { }

  getHrCandidates(): Observable<any> {
    return this.httpService.get(API_URL.HR_CANDIDATE_GET);
  }

  getHrCandidateById(code: string): any {
    return this.httpService.get(API_URL.HR_CANDIDATE_GET + '/' + code);
  }

  getHrCandidateByCode(code: string): Observable<any> {
    return this.httpService.get(API_URL.HR_CANDIDATE_GET + '?filter[where][code]=' + code);
  }

  getHrAnswersById(qsid: string){
    return this.httpService.get(API_URL.HR_ANSWER_GET +'/' + qsid, httpOptions);
  }

  getHrCandidateLikeCode(code:string){
    return this.httpService.get(API_URL.HR_CANDIDATE_GET +'?filter[where][code][like]=%' + code +'%', httpOptions);
  }

  getHrCandidateLikeUser(user:string){
    return this.httpService.get(API_URL.HR_CANDIDATE_GET +'?filter[where][username][like]=%' + user +'%', httpOptions);
  }

  getMaxIdHrQuestions(){
    return this.httpService.get(API_URL.HR_QUESTION_GET + '?filter[order]=id%20desc&filter[limit]=1', httpOptions);
  }

  getHrQuestionsByCategoryLevel(category: string, level: string){
    return this.httpService.get(API_URL.HR_QUESTION_GET + '?filter[where][category]=' + category + '&filter[where][level]=' +level, httpOptions);
  }

  getHrTestTemplateDetailsById(id: string){
    return this.httpService.get(API_URL.HR_TEST_TEMPLATE_DETAIL_GET + '?filter[where][and][0][testTemplateId]='+id);
  }

  getHrTestTemplateByCode(code: string){
    return this.httpService.get(API_URL.HR_TEST_TEMPLATE_GET + '/' + code);
  }
  getElementNameMClass(classes: any, code: string) {
    if(!classes) {
      return;
    }
    const ret = classes.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }

  addHrCandidates(hrCandidate: HrCandidate): Observable<any> {
    return this.httpService.post(API_URL.HR_CANDIDATE_GET,hrCandidate, httpOptions);
  }


  addHrQuestions(hrQuestion: HrQuestion): Observable<any> {
    return this.httpService.post(API_URL.HR_QUESTION_GET,hrQuestion, httpOptions);
  }

  addHrAnswers(hrAnswer: HrAnswer): Observable<any> {
    return this.httpService.post(API_URL.HR_ANSWER_GET,hrAnswer, httpOptions);
  }
  addHrTestTemplate(hrTestTemplate: HrTestTemplate): Observable<any> {
    return this.httpService.post(API_URL.HR_TEST_TEMPLATE_GET,hrTestTemplate, httpOptions);
  }

  addHrTestTemplateDetail(hrTestTemplateDetail: HrTestTemplateDetail): Observable<any> {
    return this.httpService.post(API_URL.HR_TEST_TEMPLATE_DETAIL_GET,hrTestTemplateDetail, httpOptions);

  }

  updateHrCandidates(hrCandidate: HrCandidate, code: string): Observable<any> {
    return this.httpService.patch(API_URL.HR_CANDIDATE_GET + '/' + code, hrCandidate, httpOptions);
  }


  updateHrQuestions(hrQuestion: HrQuestion, id: string): Observable<any> {
    return this.httpService.patch(API_URL.HR_QUESTION_GET + '/' + id, hrQuestion, httpOptions);
  }

  updateHrAnswers(hrAnswer: HrAnswer, id: string): Observable<any> {
    return this.httpService.patch(API_URL.HR_ANSWER_GET + '/' + id, hrAnswer, httpOptions);
  }

  deleteHrAnswers(id: string){
    return this.httpService.delete(API_URL.HR_ANSWER_GET + '/' + id, httpOptions);
  }
  updateTestTemplate(hrTestTemplate: HrTestTemplate, code: string): Observable<any> {
    return this.httpService.patch(API_URL.HR_TEST_TEMPLATE_GET + '/' + code, hrTestTemplate, httpOptions);
  }

  updateTestTemplateDetail(hrTestTemplateDetail: HrTestTemplateDetail, code: string): Observable<any> {
    return this.httpService.patch(API_URL.HR_TEST_TEMPLATE_DETAIL_GET + '/' + code, hrTestTemplateDetail, httpOptions);

  }

  searchHrCandidates(context: any): Observable<any> {
    
    let sql = ''
    sql = '/hr-candidates'
    Object.keys(context).forEach(element => {
      if (context[element] !== '' && context[element] != undefined) {
        if ('/hr-candidates' == sql) {
          sql += '?filter[where][' + element + '][like]=%' + context[element] + '%';
        } else {
          sql += '&filter[where][' + element + '][like]=%' + context[element] + '%';
        }
        
      }
    });
    return this.httpService.get(sql)
  }

  
  searchHrQuestions(context: any): Observable<any> {
    
    let sql = ''
    sql = '/hr-questions'
    Object.keys(context).forEach(element => {
      if (context[element] !== '' && isNaN(Number(context[element]))==false && context[element] != undefined) {
        if ('/hr-questions' == sql) {
          sql += '?filter[where][and][0][' + element + ']=' + context[element];
        } else {
          sql += '&filter[where][and][0][' + element + ']=' + context[element];
        }
        
      }
    });
    return this.httpService.get(sql)
  }



  //Search Test Template
  searchHrTestTemplates(context: any): Observable<any> {
    
    let sql = ''
    sql = '/hr-test-templates'
    Object.keys(context).forEach(element => {
      if (context[element] !== '' && context[element]!=undefined) {
        if ('/hr-test-templates' == sql) {
          if(element == 'activeFlag') {
            sql += '?filter[where][and][0][' + element + ']=' + context[element];
          }
          else {
            sql += '?filter[where][and][0][' + element + '][like]=%' + context[element] + '%';
          }
        } else {
          if(element == 'activeFlag') {
            sql += '&filter[where][and][0][' + element + ']=' + context[element];
          }
          else {
          sql += '&filter[where][and][0][' + element + '][like]=%' + context[element] + '%';
          }
        } 
      }
    });
    return this.httpService.get(sql)
  }

  deleteTestTemplateDetail(hrTestTemplateDetail: HrTestTemplateDetail): Observable<any> {
    let url = '';
    url = API_URL.HR_TEST_TEMPLATE_DETAIL_GET + '?[where][testTemplateId]=' + hrTestTemplateDetail.testTemplateId
                                              + '&[where][category]=' + hrTestTemplateDetail.category
                                              + '&[where][level]=' + hrTestTemplateDetail.level
                                              + '&[where][quantity]=' + hrTestTemplateDetail.quantity;
    return this.httpService.delete(url, httpOptions);

  }
}
