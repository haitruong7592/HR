export {HrCandidate} from '@app/models/hr/hr-candidate.model';
export {HrCandidateDto} from '@app/models/hr/hr-candidate.model';
export {HrTestTemplate, HrTestTemplateDto} from '@app/models/hr/hr-test-template.model';
export {HrTestTemplateDetail, HrTestTemplateDetailDto, InputDetail} from '@app/models/hr/hr-test-template-detail.model';


