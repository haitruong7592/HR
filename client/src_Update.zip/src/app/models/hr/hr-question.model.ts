import { Deserializable } from '@app/models/deserializable.model';
export class HrQuestion {
    id: string;
    category: string;
    level: string;
    content: string;
    image: string;
    activeflag: boolean;

    constructor() { }
}

export class HrQuestionDto extends HrQuestion implements Deserializable {

    

    deserialize(input: any) {
        Object.assign(<any>this, input);
        return this;
    }
}