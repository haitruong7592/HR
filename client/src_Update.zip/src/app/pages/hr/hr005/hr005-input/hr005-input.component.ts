import { Component, OnInit, Inject, Input } from '@angular/core';
import { HrCandidate, HrCandidateDto } from '@app/models/hr';
import {
  MAT_DIALOG_DATA, MatDialogRef, MatSnackBar
} from '@angular/material'
import { HttpService } from '@app/core/http/http.service';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { MClass } from '@app/models/m-class.model';
import { Subscriber, Observable, forkJoin, merge } from 'rxjs';
import { HrService } from '@app/core/services/hr.service';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
@Component({
  selector: 'app-hr005-input',
  templateUrl: './hr005-input.component.html',
  styleUrls: ['./hr005-input.component.scss']
})
export class Hr005InputComponent implements OnInit {
  modelTemp: any;
  model: HrCandidate;
  positions: any;
  positionSelected = '';
  templates: any;
  templateSelected = '';
  username: string;
  password: string;
  isUpdate: boolean = false;
  flagCode: boolean = false;
  flagUser: boolean;

  constructor(private httpService: HttpService,
    public dialogRef: MatDialogRef<Hr005InputComponent>,
    private hrService: HrService,
    public snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) public data: any) {

  }

  ngOnInit() {
    this.model = new HrCandidateDto();
    const sub1 = this.httpService.get(API_URL.M_CLASS_GET).subscribe((res: any) => {
      this.positions = res.filter((e: any) => e.precode === CLASS.POSITION);
      this.positions.unshift(new MClass());
    });
    // get test template data
    const sub2 = this.httpService.get(API_URL.HR_TEST_TEMPLATE_GET).subscribe((res: any) => {
      this.templates = res;
      this.templates.unshift(new MClass());
    });
    // merge data before set name for position and test template
    merge([sub1, sub2]).subscribe(() => {
      this.httpService.get(API_URL.HR_CANDIDATE_GET).subscribe((res: any) => {
        res.forEach((element: any) => {
          element.positionName = this.getPositionName(element.position);
          element.testTemplateName = this.getTestTemplateName(element.testTemplate);
        });
      });
    });
    if (this.data) {
      this.isUpdate = true;
      this.flagCode = true;
      this.flagUser = true;
      this.positionSelected = this.data.selected.position;
      this.templateSelected = this.data.selected.testTemplate;
      this.username = this.data.selected.username;
      this.password = this.data.selected.password;
      this.model = Object.assign([], this.data.selected);
      this.modelTemp = Object.assign([], this.data.selected);
    }
  }

  clear(): any {

    if (this.data) {
      this.modelTemp = Object.assign([], this.data.selected);
      this.default();
    }
    else {
      this.model = new HrCandidate();
      this.positionSelected = null;
      this.templateSelected = null;
      this.username = null;
      this.password = null;
      this.flagCode = false;
      this.flagUser = false;
    }
  }
  default(): any {
    this.model = this.modelTemp;
    this.positionSelected = this.data.selected.position;
    this.templateSelected = this.data.selected.testTemplate;
    this.username = this.data.selected.username;
    this.password = this.data.selected.password;
  }
  getTestTemplateName(code: string) {
    if (!this.templates) {
      return;
    }
    const ret = this.templates.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }

  getPositionName(code: string) {
    if (!this.positions) {
      return;
    }
    const ret = this.positions.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }
  closeDialog() {
    this.data = null;
    this.dialogRef.close();
  }
  dec2hex(dec: any) {
    return ('0' + dec.toString(16)).substr(-2)
  }

  // generateId :: Integer -> String
  generateCode(len: any) {
    var arr = new Uint8Array((len || 40) / 2)
    window.crypto.getRandomValues(arr)
    return Array.from(arr, this.dec2hex).join('')
  }
  generate() {
    this.username = this.generateCode(10);
    this.password = this.generateCode(10);
    this.hrService.getHrCandidateLikeUser(this.username).subscribe((res: any) => {

      if (res.length >= 1) {
        this.flagUser = false;
        this.snackBar.open('Username is dublicate', 'Close', {
          duration: 4000,
          verticalPosition: 'top',
          horizontalPosition: 'center'
        });
      }
      this.flagUser = true;
    })
  }

  control() {

  }

  numberOnly(event: any): boolean {

    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }

    return true;

  }
  onBlurCode() {
    if (this.model.code.length < 10) {

      this.flagCode = false;
    }
    if (this.model.code.length == 10 && this.isUpdate == false) {
      this.hrService.getHrCandidateLikeCode(this.model.code).subscribe((res: any) => {

        if (res.length >= 1) {
          this.flagCode = false;

          this.snackBar.open('Code is dublicate', 'Close', {
            duration: 4000,
            verticalPosition: 'top',
            horizontalPosition: 'center'
          });
        }
        else {
          this.flagCode = true;

        }


      })
    }
  }


}