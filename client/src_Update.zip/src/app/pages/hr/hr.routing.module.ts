import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Hr005Component } from '@app/pages/hr/hr005/hr005.component';
import { Hr005InputComponent } from '@app/pages/hr/hr005/hr005-input/hr005-input.component';
import { Hr003Component } from '@app/pages/hr/hr003/hr003.component';
import { Hr003InputComponent } from '@app/pages/hr/hr003/hr003-input/hr003-input.component';
import { Hr006Component } from '@app/pages/hr/hr006/hr006.component';
import { Hr001Component } from '@app/pages/hr/hr001/hr001.component';
import { Hr002Component } from '@app/pages/hr/hr002/hr002.component';
import { Hr007Component } from '@app/pages/hr/hr006/hr007/hr007.component';

const routes: Routes = [
  { path: 'hr005', component: Hr005Component },
  { path: 'hr005-input', component: Hr005InputComponent },
  { path: 'hr003', component: Hr003Component },
  { path: 'hr003-input', component: Hr003InputComponent },
  { path: 'hr006', component: Hr006Component},
  { path: 'hr001', component: Hr001Component},
  { path: 'hr002/:code', component: Hr002Component},
  { path: 'hr007', component: Hr007Component },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: []
})
export class HrRoutingModule {}