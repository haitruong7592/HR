import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HrCandidate } from '@app/models/hr/hr-candidate.model';
import { BaseSearchComponent } from '@app/shared';
import { HrTestTemplate} from '@app/models/hr/hr-test-template.model';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { HrService } from '@app/core/services/hr.service';


@Component({
  selector: 'app-hr001',
  templateUrl: './hr001.component.html',
  styleUrls: ['./hr001.component.scss']
})
export class Hr001Component extends BaseSearchComponent implements OnInit {
  candidate: HrCandidate =
  {
    "code": "0000000111",
    "name": "0000000003",
    "email": "dangvohoaithanh@gmail.com",
    "phone": "0000000000",
    "position": "03",
    "testTemplate": "0000000001",
    "testResult": "",
    "username": "0000000000",
    "password": "0000000000"
  }
  testTemlate: any;

  constructor(
    private hrService: HrService,
  ) { 
    super();
  }

  ngOnInit() {
    this.testTemlate = new HrTestTemplate;
    this.hrService.getHrTestTemplateByCode(this.candidate.testTemplate).subscribe(res => {
      this.testTemlate = Object.assign([],res);
      console.log(this.testTemlate);
    });
  }
}
