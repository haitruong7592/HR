import { Component, OnInit, Input } from '@angular/core';
import { HrTestTemplate } from '@app/models/hr';

@Component({
  selector: 'app-hr002-question',
  templateUrl: './hr002-question.component.html',
  styleUrls: ['./hr002-question.component.scss']
})
export class Hr002QuestionComponent implements OnInit {

  @Input() testTemplate: HrTestTemplate;

  constructor() { }

  ngOnInit() {
  }

}
