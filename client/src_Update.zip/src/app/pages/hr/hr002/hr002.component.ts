import { Component, OnInit, Input } from '@angular/core';
import { HrCandidate } from '@app/models/hr/hr-candidate.model';
import { ActivatedRoute } from '@angular/router';
import { BaseSearchComponent } from '@app/shared';
import { HrTestTemplate } from '@app/models/hr';
import { HrService } from '@app/core/services/hr.service';

@Component({
  selector: 'app-hr002',
  templateUrl: './hr002.component.html',
  styleUrls: ['./hr002.component.scss']
})
export class Hr002Component extends BaseSearchComponent implements OnInit {

  candidate: HrCandidate;
  testTemplate: HrTestTemplate;
  constructor(
    private hrService: HrService,
    private route: ActivatedRoute) {
    super();
   }
  ngOnInit() {
    this.candidate = new HrCandidate();
    this.testTemplate = new HrTestTemplate();
    const code = this.route.snapshot.paramMap.get('code');
    this.hrService.getHrCandidateById(code).subscribe((res:any) => {
      this.candidate = res;
      this.hrService.getHrTestTemplateByCode(this.candidate.testTemplate).subscribe((res2:any) => {
        this.testTemplate =  res2;
      });
    });
  }

}
