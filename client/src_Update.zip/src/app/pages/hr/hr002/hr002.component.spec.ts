import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Hr002Component } from './hr002.component';

describe('Hr002Component', () => {
  let component: Hr002Component;
  let fixture: ComponentFixture<Hr002Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Hr002Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Hr002Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
