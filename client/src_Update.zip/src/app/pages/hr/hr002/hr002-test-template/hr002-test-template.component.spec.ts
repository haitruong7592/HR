import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Hr002TestTemplateComponent } from './hr002-test-template.component';

describe('Hr002TestTemplateComponent', () => {
  let component: Hr002TestTemplateComponent;
  let fixture: ComponentFixture<Hr002TestTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Hr002TestTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Hr002TestTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
