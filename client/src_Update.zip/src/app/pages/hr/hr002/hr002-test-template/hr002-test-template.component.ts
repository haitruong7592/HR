import { Component, OnInit, Input } from '@angular/core';
import { HrTestTemplate } from '@app/models/hr';
import { HttpService } from '@app/core/http/http.service';
import { MClass } from '@app/models/m-class.model';
import { HrService } from '@app/core/services/hr.service'
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { HrTestTemplateDetail } from '@app/models/hr/hr-test-template-detail.model';
import { HrQuestion } from '@app/models/hr/hr-question.model';
@Component({
  selector: 'app-hr002-test-template',
  templateUrl: './hr002-test-template.component.html',
  styleUrls: ['./hr002-test-template.component.scss']
})
export class Hr002TestTemplateComponent implements OnInit {

  @Input() testTemplate: HrTestTemplate;
  categorys: any;
  questions: HrQuestion[] = [];
  number: number;
  testTemplateDetails: HrTestTemplateDetail[]= [];

  constructor(
    private httpService: HttpService,
    private hrService: HrService,
  ) { }

  ngOnInit() {
    //Get categorys data
    this.httpService.get(API_URL.M_CLASS_GET).subscribe((res: any) => {
      this.categorys = res.filter((e: any) => e.precode === CLASS.QUESTION_CATEGORY);
      this.categorys.unshift(new MClass());
    });

    console.log(this.testTemplate);
    this.hrService.getHrTestTemplateDetailsById(this.testTemplate.code).subscribe((res: HrTestTemplateDetail[]) => {
      for(var i = 0; i < res.length; i++){
        this.testTemplateDetails.push(res[i]);
      }
      
    }); 
  }

  //select question in test template detail
  selectQuestion(a: HrTestTemplateDetail): any{
    this.number = 0;
    if(this.questions) {
      for(let i = this.questions.length - 1; i > -1; i--){
        this.questions.splice(i,1);
      }
    }
    this.hrService.getHrQuestionsByCategoryLevel(a.category, a.level).subscribe(res =>{
      this.questions = this.selectRandomQuestion(res, a.quantity);
      console.log(this.questions);
    });
    return true;
  }
  
  //select n random question in a array
  selectRandomQuestion(a: any, n: number): any{
    var b: any[];
    this.shuffle(a);
    if(a.length >= n){
      for(let i = 0; i < n; i++){
        b.push(a[i]);
      }
    }
    return b;
  }

  //shuffle a array
  shuffle(a: any) {
    for (let i = a.length - 1; i > -1; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        if(i != j){
          [a[i], a[j]] = [a[j], a[i]];
        }
    }
    console.log(a);
    return a;
  }
}
