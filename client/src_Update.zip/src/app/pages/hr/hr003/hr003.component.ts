import { Component, OnInit, ViewChild } from '@angular/core';
import { HrTestTemplate} from '@app/models/hr/hr-test-template.model';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { HttpService } from '@app/core/http/http.service';
import { MatPaginator, MatTableDataSource, MatDialog, MatSort } from '@angular/material';
import { BaseSearchComponent } from '@app/shared';
import { Subscriber, Observable, forkJoin, merge } from 'rxjs';
import { mergeAll } from '../../../../../node_modules/rxjs/operators';
import { Hr003InputComponent } from '@app/pages/hr/hr003/hr003-input/hr003-input.component';
import { HrService } from '@app/core/services/hr.service';
import { MClass } from '@app/models/m-class.model';

@Component({
  selector: 'app-hr003',
  templateUrl: './hr003.component.html',
  styleUrls: ['./hr003.component.scss']
})
export class Hr003Component extends BaseSearchComponent implements OnInit {


    model: HrTestTemplate;
    modelnew: HrTestTemplate;
    selected: HrTestTemplate;
    // Search condition
    code: string;
    name: string;
    time: number;
    activeFlags: any;
    // Data table
    displayedColumns: any[] = [
      'code',
      'name',
      'time',
      'activeFlag'
    ];
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    dataSource: any = new MatTableDataSource<HrTestTemplate>([]);

  constructor(
    private hrService: HrService,
    private httpService: HttpService,
    public dialog: MatDialog) {
    super();
   }

   
  /**
   * Initialize data
   *
   * @memberof Hr003Component
   */

  ngOnInit() {
    this.modelnew = new HrTestTemplate();
    this.model = new HrTestTemplate();
    this.refreshData();
    //Get data activeflag from Table m_class;
    this.httpService.get(API_URL.M_CLASS_GET).subscribe((res: any) => {
      this.activeFlags = res.filter((e: any) => e.precode === CLASS.ACTIVE_FLAG);
      this.activeFlags.unshift(new MClass());
    });
  }

  refreshData() {
    this.httpService.get(API_URL.HR_TEST_TEMPLATE_GET).subscribe((res: any) => {
      this.dataSource = new MatTableDataSource<HrTestTemplate>(res);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  selectRow(row: any): any{
    this.selected = row;
  }
  
  // Open dialog to create new
  openDialogNew() {
    const dialogRef = this.dialog.open(Hr003InputComponent,{
      width: '80%', height:'80%',
      data: this.modelnew
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      if(result){
        this.refreshData();
      }
    });
  }

  //open dialog to update
  openDialogUpdate(row: HrTestTemplate) {
    const dialogRef = this.dialog.open(Hr003InputComponent, {
      width: '80%', height:'80%',
      data: this.model = row
    });
    dialogRef.afterClosed().subscribe((result: any) => {
      if(result){
        this.refreshData();
      }
    });  
  }

  search(code: string, name: string, active: string) {
    let activeFlag: boolean;
    if(active == "02") activeFlag = true;
    if(active == "03") activeFlag = false;
    this.hrService.searchHrTestTemplates({code: code, name: name, time: null, activeFlag: activeFlag}).subscribe((res: any) => {
      this.dataSource = new MatTableDataSource<HrTestTemplate>(res);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }
}
