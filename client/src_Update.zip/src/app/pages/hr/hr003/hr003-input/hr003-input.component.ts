import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { HttpService } from '@app/core/http/http.service';
import { HrTestTemplateDetail, InputDetail} from '@app/models/hr/hr-test-template-detail.model';
import { HrService } from '@app/core/services/hr.service'
import { HrTestTemplate } from '@app/models/hr';
import { FormControl,Validators, FormGroup } from '@angular/forms';
import { BaseSearchComponent } from '@app/shared';
import { MatSnackBar} from '@angular/material';

@Component({
  selector: 'app-hr003-input',
  templateUrl: './hr003-input.component.html',
  styleUrls: ['./hr003-input.component.scss']
})


export class Hr003InputComponent extends BaseSearchComponent implements OnInit {
  editForm: FormGroup;
  inputDetails: InputDetail[]= [];
  model: InputDetail;
  mod: HrTestTemplate;  
  id: number; 
  disableCode: boolean;
  dissableSave: boolean;
  readonly: boolean;

  constructor(
    private httpService: HttpService,
    private hrService: HrService,
    public dialogRef: MatDialogRef<Hr003InputComponent>,
    public snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) public data: any,
    
  ) {
    super();
   }

  ngOnInit() {
    this.model = new InputDetail();
    this.mod = new HrTestTemplate();
    this.id = 0;
    if(this.data.code){
      this.default();
      this.readonly = true;
    }
    else {
      this.inputDetails.push(this.model);
      this.disableCode = false;
    }
    if(this.mod.code === '' || this.mod.name === '') this.dissableSave = true;
    else this.dissableSave = false;
    this.editForm = new FormGroup({
      codeTest: new FormControl('', [Validators.required,]),
      nameTest: new FormControl('', Validators.required)
    });
  }
  
  default() :any{ 
    this.mod.code = this.data.code;
    this.mod.name = this.data.name;
    this.mod.time = this.data.time;
    this.mod.activeFlag = this.data.activeFlag;
    this.disableCode = true;
    this.hrService.getHrTestTemplateDetailsById(this.data.code).subscribe((res: HrTestTemplateDetail[]) => {
      for(var i = 0; i < res.length; i++){
        var input: InputDetail;
        input = new InputDetail();
        this.id =i;
        input.id = i;
        input.hrTestTemplateDetail = res[i];
        this.inputDetails.push(input);
      }
    }); 
  }

  newDetail(): any{
    var input: InputDetail;
    input = new InputDetail();
    this.id = this.id + 1;
    input.id = this.id;
    this.inputDetails.push(input);
  }

  //Delete a test template detail 
  deleteModel(model: any){
    let x = this.inputDetails.findIndex( record => record === model);
    this.inputDetails.splice(x,1);
  }

  onClear(): any {
    let modelNew: InputDetail;
    modelNew = new InputDetail;
    for(let i = this.inputDetails.length - 1; i > -1; i--){
          this.inputDetails.splice(i,1);
    }
    if(this.data.code){
      this.default();
    }
    else {
      this.mod.code = null;
      this.mod.name = null;
      this.mod.time = null;
      this.mod.activeFlag = null;
      this.inputDetails.push(modelNew);
    }
  }

  openMessage(message: string): any {
    this.snackBar.open(message, 'Close', {
      duration: 5000,
    });
  }

  //Add and update test tempate and test template detail
  save(mod: HrTestTemplate, models: any): any{
    if(mod.code && mod.name){
      //remove the same element about category, level
      let isExist = (arr: HrTestTemplateDetail[], x: HrTestTemplateDetail) => {
        for(let i = 0; i < arr.length; i++){
          if(arr[i].category === x.category && arr[i].level === x.level) {
            arr[i].quantity = arr[i].quantity + x.quantity;
            return true;
          }
        }
        return false;
      }
      var templateDetail: HrTestTemplateDetail[] = [];
      models.forEach((output: any) => {
        output.hrTestTemplateDetail.testTemplateId = mod.code; 
        if(!isExist(templateDetail, output.hrTestTemplateDetail)) templateDetail.push(output.hrTestTemplateDetail);
      });

      //Add new
      if(!this.data.code){
        this.hrService.searchHrTestTemplates({code: mod.code, name: null, time: null, activeFlag: null}).subscribe(res => {
          if(res.length > 0) {
            this.openMessage('Add new is unsuccessful! Code is exist');
          }
          else {
            this.hrService.addHrTestTemplate(mod).subscribe(res1 =>{
              templateDetail.forEach(res2 =>{
                if(res2.category && res2.level) {
                  //Add test template details 
                  this.hrService.addHrTestTemplateDetail(res2).subscribe(res3 =>
                    console.log(res3)
                  );
                }
              });
              }
            );
            this.openMessage('Add new is successful');
          }  
        });
      }

      //Update
      else {
        //Update test template
        this.hrService.updateTestTemplate(mod, mod.code).subscribe(result => {
          let isExistDetail = (arr: HrTestTemplateDetail[], x: HrTestTemplateDetail) => {
            for(let i = 0; i < arr.length; i++){
              if(arr[i].category == x.category && arr[i].level == x.level && arr[i].quantity == x.quantity) {
                return true;
              }
            }
            return false;
          } 
          this.hrService.getHrTestTemplateDetailsById(this.data.code).subscribe((res: any) =>{
            res.forEach((oldValue: HrTestTemplateDetail) => {
              if(!isExistDetail(templateDetail, oldValue)) {
                //Delete detail 
                this.hrService.deleteTestTemplateDetail(oldValue).subscribe(); 
              } 
              else {
                for(let i = templateDetail.length - 1; i > -1; i--) {
                  if(templateDetail[i].category == oldValue.category && templateDetail[i].level == oldValue.level && templateDetail[i].quantity == oldValue.quantity) {
                    templateDetail.splice(i,1);
                  }
                }
              }
            })
            //Add new detail
            templateDetail.forEach(detail => {
              if(detail.category && detail.level){
                this.hrService.addHrTestTemplateDetail(detail).subscribe();
              }
            })
          });
          this.openMessage('Update is successful');
        });
        
      }
    }
  }
}


