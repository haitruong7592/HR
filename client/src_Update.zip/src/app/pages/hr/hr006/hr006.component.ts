import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatDialog, MatSort, MAT_CHECKBOX_CLICK_ACTION } from '@angular/material';
import { HrQuestion } from '@app/models/hr/hr-question.model';
import { HrService } from '@app/core/services/hr.service'
import { HttpService } from '@app/core/http/http.service';
import { BaseSearchComponent } from '@app/shared';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { MClass } from '@app/models/m-class.model';
import { Subscriber, Observable, forkJoin, merge } from 'rxjs';
import { Hr007Component } from '@app/pages/hr/hr006/hr007/hr007.component';
import { HrAnswer } from '@app/models/hr/hr-answer.model';

@Component({
  selector: 'app-hr006',
  templateUrl: './hr006.component.html',
  styleUrls: ['./hr006.component.scss'],
})

export class Hr006Component extends BaseSearchComponent implements OnInit {
  // Search condition
  model: HrQuestion;

  categorys: any;
  levels: any;
  categorySelected = '';
  levelSelected = '';
  image: string;
  activeFlag: boolean;
  selected: HrQuestion;
  isIndeterminate: boolean = false;
  // Data table
  displayedColumns: string[] = [
    'id',
    'categoryName',
    'levelName',
    'content',
    'image',
    'activeFlag'
  ];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource: any = new MatTableDataSource<HrQuestion>([]);
  constructor(private httpService: HttpService,
    private hrService: HrService, public dialog: MatDialog) {
    super();
  }

  ngOnInit() {
    this.model = new HrQuestion();

    // get position data
    const sub1 = this.httpService.get(API_URL.M_CLASS_GET).subscribe((res: any) => {
      this.categorys = res.filter((e: any) => e.precode === CLASS.QUESTION_CATEGORY);
      this.categorys.unshift(new MClass());
    });
    // get test template data
    const sub2 = this.httpService.get(API_URL.M_CLASS_GET).subscribe((res: any) => {
      this.levels = res.filter((e: any) => e.precode === CLASS.QUESTION_LEVEL);
      this.levels.unshift(new MClass());
    });
    merge([sub1, sub2]).subscribe(() => {
      this.refreshData()
    });
  }

  refreshData() {
    this.httpService.get(API_URL.HR_QUESTION_GET).subscribe((res: any) => {
      res.forEach((element: any) => {
        element.categoryName = this.getCategoryName(element.category);
        element.levelName = this.getLevelName(element.level);
      });
      this.dataSource = new MatTableDataSource<HrQuestion>(res);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }
  getCategoryName(code: string) {
    if (!this.categorys) {
      return;
    }
    const ret = this.categorys.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }

  getLevelName(code: string) {
    if (!this.levels) {
      return;
    }
    const ret = this.levels.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }

  selectRow(row: HrQuestion) {
    this.selected = row;
  }

  //mode update
  readonly: boolean = true;
  openDialog() {

    const dialogRef = this.dialog.open(Hr007Component, {
      disableClose: true,
      width: '70%', maxHeight: '90vh',
      data: {
        selected: this.selected,
        readonly: this.readonly
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {

        this.hrService.updateHrQuestions(result, this.selected.id).subscribe(result => {
          this.refreshData();
        })
      };
    });
  }
  qsid: string
  openDialogNew() {

    const dialogRef = this.dialog.open(Hr007Component, {
      disableClose: true,
      width: '70%', maxHeight: '90vh',
    });
    dialogRef.beforeClose().subscribe(result => {
      if (result) {
        this.hrService.addHrQuestions(result).subscribe(result => {
          this.refreshData();
        })
      }
    });
  }

  search(id: number, category: string, level: string, content: string, active: boolean) {
    this.hrService.searchHrQuestions({ id: id, category: category, level: level, content: content, activeflag: active }).subscribe((res: any) => {
      res.forEach((element: any) => {
        element.categoryName = this.getCategoryName(element.category);
        element.levelName = this.getLevelName(element.level);
      });
      this.dataSource = new MatTableDataSource<HrQuestion>(res);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

}
