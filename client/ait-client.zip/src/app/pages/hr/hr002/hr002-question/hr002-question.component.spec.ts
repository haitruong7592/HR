import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Hr002QuestionComponent } from './hr002-question.component';

describe('Hr002QuestionComponent', () => {
  let component: Hr002QuestionComponent;
  let fixture: ComponentFixture<Hr002QuestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Hr002QuestionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Hr002QuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
