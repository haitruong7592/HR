import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Hr003Component } from './hr003.component';

describe('Hr003Component', () => {
  let component: Hr003Component;
  let fixture: ComponentFixture<Hr003Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Hr003Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Hr003Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
