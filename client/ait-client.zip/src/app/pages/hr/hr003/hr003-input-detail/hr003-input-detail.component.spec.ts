import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Hr003InputDetailComponent } from './hr003-input-detail.component';

describe('Hr003InputDetailComponent', () => {
  let component: Hr003InputDetailComponent;
  let fixture: ComponentFixture<Hr003InputDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Hr003InputDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Hr003InputDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
