import { Component, OnInit, ViewChild } from '@angular/core';
import { HrCandidate } from '@app/models/hr/hr-candidate.model';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { HttpService } from '@app/core/http/http.service';
import { MClass } from '@app/models/m-class.model';
import { MatPaginator, MatTableDataSource, MatDialog, MatSort } from '@angular/material';
import { BaseSearchComponent } from '@app/shared';
import { Subscriber, Observable, forkJoin, merge } from 'rxjs';
import { mergeAll } from '../../../../../node_modules/rxjs/operators';
import { Hr005InputComponent } from '@app/pages/hr/hr005/hr005-input/hr005-input.component';
import { HrService } from '@app/core/services/hr.service'
import { componentFactoryName } from '@angular/compiler';
@Component({
  selector: 'app-hr005',
  templateUrl: './hr005.component.html',
  styleUrls: ['./hr005.component.scss']
})

export class Hr005Component extends BaseSearchComponent implements OnInit {
  // Search condition
  model: HrCandidate;
  positions: any;
  positionSelected = '';
  templates: any;
  templateSelected = '';
  contacts: Array<any>;

  // Data table
  displayedColumns: string[] = [
    'code',
    'name',
    'email',
    'phone',
    'positionName',
    'testTemplateName',
    'username',
    'password'
  ];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource: any = new MatTableDataSource<HrCandidate>([]);
  selected: HrCandidate;

  constructor(private httpService: HttpService,
    private hrService: HrService, public dialog: MatDialog) {
    super();
    this.contacts = [];
  }

  /**
   * Initialize data
   *
   * @memberof Hr005Component
   */
  ngOnInit() {
    this.model = new HrCandidate();
    // get position data
    const sub1 = this.httpService.get(API_URL.M_CLASS_GET).subscribe((res: any) => {
      this.positions = res.filter((e: any) => e.precode === CLASS.POSITION);
      this.positions.unshift(new MClass());
    });
    // get test template data
    const sub2 = this.httpService.get(API_URL.HR_TEST_TEMPLATE_GET).subscribe((res: any) => {
      this.templates = res;
      this.templates.unshift(new MClass());
    });
    // merge data before set name for position and test template
    merge([sub1, sub2]).subscribe(() => {
      this.refreshData();
    });
  }
  refreshData() {
    this.httpService.get(API_URL.HR_CANDIDATE_GET).subscribe((res: any) => {
      res.forEach((element: any) => {
        element.positionName = this.getPositionName(element.position);
        element.testTemplateName = this.getTestTemplateName(element.testTemplate);
      });
      this.dataSource = new MatTableDataSource<HrCandidate>(res);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }
  clear(): any {
    this.model = new HrCandidate();
    this.positionSelected = null;
    this.templateSelected = null
  }
  /**
   * Get name for position
   *
   * @param {string} code
   * @returns
   * @memberof Hr005Component
   */
  getPositionName(code: string) {
    if (!this.positions) {
      return;
    }
    const ret = this.positions.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }
  search(code: string, name: string, email: string, phone: string, pos: string, template: string) {
    this.hrService.searchHrCandidates({ code: code, name: name, email: email, phone: phone, position: pos, testTemplate: template }).subscribe((res: any) => {
      res.forEach((element: any) => {
        element.positionName = this.getPositionName(element.position);
        element.testTemplateName = this.getTestTemplateName(element.testTemplate);
      });
      this.dataSource = new MatTableDataSource<HrCandidate>(res);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    })
  }

  numberOnly(event: any): boolean {

    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }

    return true;

  }

  /**
   * Get name for test template
   *
   * @param {string} code
   * @returns
   * @memberof Hr005Component
   */
  getTestTemplateName(code: string) {
    if (!this.templates) {
      return;
    }
    const ret = this.templates.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }
  selectRow(row: HrCandidate) {
    // this.code1=(row['code']);
    // this.name1=(row['name']);
    this.selected = row;
  }

  readonly: boolean = true;
  //mode update
  openDialog() {

    const dialogRef = this.dialog.open(Hr005InputComponent, {
      disableClose: true,
      width: '70%',
      data: {
        selected: this.selected,
        readonly: this.readonly,
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.hrService.updateHrCandidates(result, result.code).subscribe(result => {
          this.refreshData();
        })
      };
    });
  }
  //mode new
  openDialogNew() {

    const dialogRef = this.dialog.open(Hr005InputComponent, {
      disableClose: true,
      width: '70%'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.hrService.addHrCandidates(result).subscribe(result => {
          this.refreshData();
        })
      }
      this.refreshData();
    });
  }
}



