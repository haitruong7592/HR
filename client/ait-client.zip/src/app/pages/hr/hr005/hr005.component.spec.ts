import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Hr005Component } from '@app/pages/hr/hr005/hr005.component';

describe('Hr005Component', () => {
  let component: Hr005Component;
  let fixture: ComponentFixture<Hr005Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Hr005Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Hr005Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
