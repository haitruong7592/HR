import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Hr005InputComponent } from './hr005-input.component';

describe('Hr005InputComponent', () => {
  let component: Hr005InputComponent;
  let fixture: ComponentFixture<Hr005InputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Hr005InputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Hr005InputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
