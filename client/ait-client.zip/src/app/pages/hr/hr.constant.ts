export enum CLASS {
  POSITION = '0001',
  QUESTION_CATEGORY = '0002',
  QUESTION_LEVEL = '0003',
  ACTIVE_FLAG = '0004'
}
export enum API_URL {
  M_CLASS_GET = '/m-classes',
  HR_TEST_TEMPLATE_GET = '/hr-test-templates',
  HR_CANDIDATE_GET = '/hr-candidates',
  HR_QUESTION_GET = '/hr-questions',
  HR_ANSWER_GET = '/hr-answers',
  HR_TEST_TEMPLATE_DETAIL_GET = '/hr-test-template-details',
}
