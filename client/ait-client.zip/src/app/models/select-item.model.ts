export interface SelectItem {
  value: string;
  label: string;
}
