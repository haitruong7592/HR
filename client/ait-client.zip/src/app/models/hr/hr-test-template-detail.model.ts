import { Deserializable } from '@app/models/deserializable.model';

export class HrTestTemplateDetail {
  testTemplateId: string;
  category: string;
  level: string; 
  quantity: number;
  constructor() {
    this.testTemplateId = '';
    this.category = '';
    this.level = '';
    this.quantity = 0;
  }
}

export class HrTestTemplateDetailDto extends HrTestTemplateDetail implements Deserializable {
  categoryName: string;
  levelName: string;
  deserialize(input: any) {
    Object.assign(<any>this, input);
    return this;
  }
}

export class InputDetail{
  id: number;
  hrTestTemplateDetail: HrTestTemplateDetail;
  constructor(){
    this.id = 0;
    this.hrTestTemplateDetail = new HrTestTemplateDetail;
  }
}
