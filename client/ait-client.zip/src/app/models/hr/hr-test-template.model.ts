import { Deserializable } from '@app/models/deserializable.model';

export class HrTestTemplate {
  code: string;
  name: string;
  time: number;
  activeFlag: boolean;
  constructor() {
    this.code = '';
    this.name = '';
    this.time = 0;
    this.activeFlag = false;
  }
}

export class HrTestTemplateDto extends HrTestTemplate implements Deserializable {
  deserialize(input: any) {
    Object.assign(<any>this, input);
    return this;
  }
}
