import { Deserializable } from '@app/models/deserializable.model';
export class HrAnswer {
    id: string;
    content: string;
    image: string;
    questionid: number;
    correct: boolean;

    constructor() {
        this.content = '';
        this.image = '';
        this.questionid = null;
        this.correct = false;
    }


}

export class HrAnswerDto extends HrAnswer implements Deserializable {



    deserialize(input: any) {
        Object.assign(<any>this, input);
        return this;
    }
}
// dec2hex :: Integer -> String
function dec2hex(dec: any) {
    return ('0' + dec.toString(16)).substr(-2)
}

// generateId :: Integer -> String
function generateId(len: any) {
    var arr = new Uint8Array((len || 40) / 2)
    window.crypto.getRandomValues(arr)
    return Array.from(arr, dec2hex).join('')
}
