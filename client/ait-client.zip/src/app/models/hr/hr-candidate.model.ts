import { Deserializable } from '@app/models/deserializable.model';

export class HrCandidate  {
  code: string;
  name: string;
  email: string;
  phone: string;
  position: string;
  testTemplate: string;
  testResult: string;
  username: string;
  password: string;
  constructor() {
    this.code = '';
    this.name = '';
    this.email = '';
    this.phone = '';
    this.position='';
    this.testTemplate='';
    this.username='';
    this.password='';
  }
}

export class HrCandidateDto extends HrCandidate implements Deserializable {
  
  positionName: string;
  testTemplateName: string;

  deserialize(input: any) {
    Object.assign(<any>this, input);
    return this;
  }
}

