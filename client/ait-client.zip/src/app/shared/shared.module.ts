import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexLayoutModule } from '@angular/flex-layout';

import { MaterialModule } from '@app/material.module';
import { LoaderComponent } from '@app/shared/loader/loader.component';
import { BaseSearchComponent } from './base-search/base-search.component';
import { BaseInputComponent } from './base-input/base-input.component';
import { ForbiddenValidatorDirective } from './messege-error/forbidden-name.directive'
@NgModule({
  imports: [
    FlexLayoutModule,
    MaterialModule,
    CommonModule,
    
  ],
  declarations: [
    LoaderComponent,
    BaseSearchComponent,
    BaseInputComponent,
    ForbiddenValidatorDirective,
  ],
  exports: [
    LoaderComponent
  ]
})
export class SharedModule { }
